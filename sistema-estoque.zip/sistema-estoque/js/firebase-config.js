// Configuracao do Firebase.
// Cole aqui os dados do seu projeto (Console do Firebase > Configuracoes do projeto > Seus apps > App da Web).
// Enquanto estes valores nao forem preenchidos, o sistema funciona em MODO DEMONSTRACAO,
// salvando os dados apenas no navegador de quem esta usando.
export const firebaseConfig = {
  apiKey: "COLE_AQUI",
  authDomain: "COLE_AQUI",
  projectId: "COLE_AQUI",
  storageBucket: "COLE_AQUI",
  messagingSenderId: "COLE_AQUI",
  appId: "COLE_AQUI"
};
