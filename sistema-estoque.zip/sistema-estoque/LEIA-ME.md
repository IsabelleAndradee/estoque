# Sistema de Estoque

Sistema web de controle de estoque: produtos, fornecedores, colaboradores, entradas, saídas, saldo, análise de compras e check list de envio.

Feito em HTML, CSS e JavaScript puro, sem etapa de build. O banco de dados e o login usam o Firebase (Firestore e Authentication).

## Arquivos

| Arquivo | Para que serve |
| --- | --- |
| `index.html` | Página do sistema |
| `css/estilo.css` | Cores, fonte e aparência |
| `js/firebase-config.js` | Dados do seu projeto Firebase (único arquivo que você precisa editar) |
| `js/dados.js` | Comunicação com o Firebase e login |
| `js/regras.js` | Cálculo do saldo e da análise de compras |
| `js/telas.js` | Telas e formulários |
| `js/app.js` | Menu, navegação e tela de login |
| `js/util.js` | Formatação, janelas e avisos |
| `firestore.rules` | Regras de segurança do banco |

## Modo demonstração

Enquanto o arquivo `js/firebase-config.js` não for preenchido, o sistema funciona em modo demonstração: tudo funciona, mas os dados ficam salvos só no navegador de quem está usando. Serve para conhecer as telas. Uma faixa no alto da página avisa quando esse modo está ativo.

## Como configurar o Firebase

1. Acesse https://console.firebase.google.com e crie um projeto.
2. No menu **Authentication**, clique em **Começar**, abra a aba **Método de login** e ative **E-mail/senha**.
3. No menu **Firestore Database**, clique em **Criar banco de dados** e escolha o modo de produção.
4. Na aba **Regras** do Firestore, apague o conteúdo, cole o conteúdo do arquivo `firestore.rules` e clique em **Publicar**.
5. Em **Configurações do projeto**, na seção **Seus apps**, adicione um **app da Web**. O Firebase mostra um bloco `firebaseConfig`. Copie os valores para o arquivo `js/firebase-config.js`.

Os valores do `firebaseConfig` não são senha e podem ficar no repositório. A proteção dos dados é feita pelas regras do passo 4.

## Como publicar pelo GitHub

1. Envie todos os arquivos desta pasta para um repositório no GitHub.
2. No repositório, abra **Settings > Pages**, escolha a branch principal e a pasta raiz, e salve. O GitHub informa o endereço do sistema.
3. No Firebase, em **Authentication > Configurações > Domínios autorizados**, adicione o domínio do GitHub Pages (exemplo: `seu-usuario.github.io`).

## Primeiro acesso

Na primeira vez que o sistema for aberto, ele pede para criar o usuário inicial (nome, sobrenome e senha). Depois disso, novos usuários são cadastrados dentro do sistema, no menu **Usuários**.

## Como testar no computador

O sistema precisa ser aberto por um endereço `http`, não funciona abrindo o `index.html` direto do disco. Para testar localmente, abra um terminal nesta pasta e rode:

```
python -m http.server 8000
```

Depois acesse http://localhost:8000 no navegador.

## Observações técnicas

- O login é por nome, sobrenome e senha. Internamente o sistema monta um e-mail técnico a partir do nome (exemplo: `maria.souza@usuarios.example.com`) para usar o Firebase Authentication. Esse e-mail nunca aparece para o usuário e nenhum e-mail é enviado.
- A senha precisa ter pelo menos 6 caracteres (exigência do Firebase).
- Nada é apagado do banco. Produtos, fornecedores e colaboradores são inativados. Entradas e saídas excluídas ficam marcadas como excluídas e deixam de contar no saldo.
- Toda edição ou exclusão de entrada e saída é gravada na coleção `auditoria`, que não pode ser alterada.
- Não existe tela para trocar senha ou remover usuário. Isso é feito no console do Firebase, em **Authentication**.
- O sistema carrega todos os registros ao entrar. Para um estoque com dezenas de milhares de movimentações, será preciso paginar as consultas.
